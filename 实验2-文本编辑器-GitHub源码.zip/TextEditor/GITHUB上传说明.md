# GitHub 上传说明

这个包已经包含一个本地 Git 仓库（`.git`），里面有按功能分阶段的提交记录，
可以直接推到 GitHub；也可以只把源码上传到网页。

## 仓库里应该有什么

```text
TextEditor.pro
main.cpp / mainwindow.* / codeeditor.* / documentio.*
finddialog.* / replacedialog.* / aboutdialog.*
resources.qrc / resources/icons/
demo/
tests/
report/实验2-简单文本编辑器-黄俊豪-定稿.docx
report/test_output.txt
README.md / GIT_COMMIT_PLAN.md / DEMO_SCRIPT.md
交付说明.txt / GITHUB上传说明.md
.gitignore
```

**不要提交**：

- `bin/`（Qt DLL、exe，约 35 MB）
- `build/`、`tests/build/`、`tools/build/`
- `*.user`、`*.o`、`moc_*.cpp`、`qrc_*.cpp`、`ui_*.h`

`.gitignore` 已经把这些排除了。

## 方法 A：保留提交历史（推荐）

1. 解压本包，进入 `TextEditor` 目录。
2. 在 GitHub 新建一个空仓库（不要勾选 README、.gitignore、License）。
3. 在 `TextEditor` 目录打开 PowerShell：

```powershell
# 如果本机没有 git，可以用这个便携版：
# C:\Users\12498\AppData\Local\Programs\Lucky\deps\PortableGit\cmd\git.exe

git remote add origin https://github.com/<你的用户名>/<仓库名>.git
git branch -M main
git push -u origin main
```

推送时会要求登录 GitHub；按提示完成浏览器登录即可。
推完后执行 `git log --oneline --graph`，应能看到 7 条左右的提交记录。

## 方法 B：网页上传（只有一条提交）

如果不想用 Git 命令：

1. 打开 GitHub 仓库页面。
2. `Add file → Upload files`。
3. 打开解压后的 `TextEditor` 目录，把**目录里的内容**（不是外层 TextEditor 文件夹）
   拖进网页；不要拖 `bin`、`build`、`.git`。
4. 填提交信息，例如 `feat: 完成 Qt 多窗口文本编辑器`，提交。

这种方法也能交，但提交历史只有一条，不如方法 A 的过程完整。

## 提交后

- 截一张 GitHub 仓库首页或 `git log --oneline --graph` 的图，补进实验报告
  “Github日志”一节。
- 可执行程序和 Qt 运行库在**完整交付包**的 `bin/` 里，不放进 GitHub 源码仓库。
